1. Prepare MATLAB software, version 2021 or higher is recommended
2. Enter "demo" in the command line of MATLAB will run the test
3. Set parameters of MPEDM at line 53-62 of demo.m
4. Change testset of MPEDM at line 28 of demo.m