%%*************************************************************************
%% This is the algorithm in the following paper:
%% A Euclidean Distance Matrix Model for Convex Clustering. Zhaowei Wang, Xiaowen Liu, Qingna Li. Journal of Optimization Theory and Applications.
%% MP-EDM -- Majorization Penalty Euclidean Distance Matrix method
%% Copyright (c) 2023 by
%% Zhaowei Wang, Qingna Li and Xiaowen Liu
%% Last modified by Zhaowei Wang and Qingna Li on 2023.12.15
%% Please contact qnl@bit.edu.cn and wangzhaowei23@mails.ucas.ac.cn for more information
%% Input 
%%   option : parameters of MP-EDM
%%      option.r : rhs of rank constraint rank(JXJ) <= r
%%      option.batch: number of data points
%%      option.max_iter: max iteration count
%%      option.phi: defines the weight matrix W, W_ij = exp(-\phi * (x_i-x_j)^2) if a_i \in KNN(a_j) or a_j \in KNN(a_i)
%%      option.k : defines the neighbor of a_i : KNN(a_i) = {a_j | a_j is a_i's k-nearest neighbor}
%%      option.gamma : penalty parameter for original clustering problem
%%      option.rho : penalty parameter for subproblem
%%      option.Fbound : convergence tolerance, \epsilon_F
%%      option.Kbound : convergence tolerance, \epsilon_K
%%      option.clusterTol : convergence tolerance, \epsilon_d
%%   A : positions of the the given points, \in R^{d * n}
%% Output
%%   output :
%%      output.timecost : cpu time cost in seconds
%%      output.iternum : iteration number of algorithm
%%   new_label : clustering results of MP-EDM, \in R^{n}
%%*************************************************************************

function [output, new_label] =  MP_EDM(option, A)
    d = size(A, 1);
    % parameter correction
    if option.r >= 2 * option.batch-1 || option.r == inf
        option.r = d;
    end
    if option.rho == -1
        option.rho = floor(sqrt(option.batch));
    end
    if option.k == -1
        option.k = int32(0.05 * option.batch);
    end
    nn = 2*option.batch;
    
    % time start
    t1 = tic();

    A = mapminmax(A,0,1);
    D00 = dist(A).^2;
    D0 = [D00,D00;D00,D00];

    % calculate weight matrix by equation (21) in the article
    omega = zeros(nn,nn);
    [~,ep] = sort(D00,2,'ascend'); % ep = column_index
    for i = 1:nn/2
        for j = 2:option.k+1
            omega(i + nn/2, ep(i,j) + nn/2) = exp(-option.phi*D0(i, ep(i,j)));
        end
    end
    option.omega = (omega + omega')/2;
    W = zeros(nn,nn);
    for i = 1:nn/2
        W(i,i+nn/2)  = 1/2;
    end
    option.W = (W+W')/2;
    
    % calculate conditional positive cone by Remark 4, using eigenvalue decomposition
    [pik_z, option.lambda, option.lambdaplus] = pi_k(-D0,option);
    option.fp0 = fp(D0,pik_z,option);

    fprintf("Solving......\n");
    iter_time = 0;
    for iter = 1:option.max_iter
        iter_time = iter_time + 1;
        
        %% solving subproblem (16)
        % initialization of D
        D = zeros(nn);
        tmp1 = -option.W/option.rho - pik_z;
        tmp2 = option.gamma/option.rho * option.omega;
        
        % solve (18) by kadan formular, following Proposition 2
        for i = 1:nn/2
            for j = nn/2+1:nn
                % r= (a/3)^(3/2), \xi = 1/3 * arcos(-b/4r)
                a = tmp1(i,j);
                b = tmp2(i,j);
                r0 = (a/3)^(1.5);
                % case 1 and case 2.1 of Prop 2
                if a <= 0 || b > 4*r0
                    X = 0;
                % case 2.2
                elseif b == 0
                    X = a;
                else
                    r1 = 2*r0^(1/3);
                    theta = 1/3*acos(-b/(4*r0));
                    x1 = r1*cos(theta);
                    x2 = r1*cos(theta + 2*pi/3);
                    x3 = r1*cos(theta + 4*pi/3);
                    X = max([x1 x2 x3]);
                    f1 = a^2/2;
                    f2 = 0.5*(X-a)^2 + b*sqrt(X);
                    if f1 < f2
                        X = 0;
                    end
                end
                D(i,j) = X;
            end
        end
        
        for i = nn/2+1:nn
            for j = i+1:nn
                % r= (a/3)^(3/2), \xi = 1/3 * arcos(-b/4r)
                a = tmp1(i,j);
                b = tmp2(i,j);
                r0 = (a/3)^(1.5);
                % case 1 and case 2.1 of Prop 2
                if a <= 0 || b > 4*r0
                    X = 0;
                % case 2.2
                elseif b == 0
                    X = a;
                else
                    r1 = 2*r0^(1/3);
                    theta = 1/3*acos(-b/(4*r0));
                    x1 = r1*cos(theta);
                    x2 = r1*cos(theta + 2*pi/3);
                    x3 = r1*cos(theta + 4*pi/3);
                    X = max([x1 x2 x3]);
                    f1 = a^2/2;
                    f2 = 0.5*(X-a)^2 + b*sqrt(X);
                    if f1 < f2
                        X = 0;
                    end
                end
                D(i,j) = X;
            end
        end

        D = D + D';
        D(1:nn/2,1:nn/2) = D00;
        
        %% Exit criterion calculation
        [pik_z, option.lambda, option.lambdaplus] = pi_k(-D,option);
        option.fp1 = fp(D,pik_z,option);
        % Fprog = (F_\rho(D^{\zeta-1}) - F_\rho(D^\zeta)) / (1 + F_\rho(D^{\zeta-1}))  
        % Kprog = 1 - \sum_{i=1}^r (\lambda_i^2-(\lambda_i-\lambda^+ )^2 / \sum_{i=1}^nn \lambda_i^2.
        Fprog = (option.fp0 - option.fp1)/(1 + option.fp0);
        tmp1 = sum(option.lambda.^2 - (option.lambda-option.lambdaplus).^2);
        tmp2 = sum(option.lambda.^2);
        Kprog = 1 - tmp1/tmp2;
        if abs(Fprog) < sqrt(option.batch)*option.Fbound && Kprog <= option.Kbound
            fprintf("  Successfully exit. Criteria:\n\n");
%             fprintf("  abs(Fprog)      : %f\n", abs(Fprog));
%             fprintf("  abs(Fprog) bound: %f\n\n", sqrt(option.batch)*option.Fbound);        
%             fprintf("  Kprog           : %f\n", Kprog);
%             fprintf("  Kprog bound     : %f\n\n", option.Kbound);     
            break
        end
        if (iter == option.max_iter)
            fprintf("  Max iter reached. Criteria:\n\n");
%             fprintf("  abs(Fprog)      : %f\n", abs(Fprog));
%             fprintf("  abs(Fprog) bound: %f\n\n", sqrt(option.batch)*option.Fbound);        
%             fprintf("  Kprog           : %f\n", Kprog);
%             fprintf("  Kprog bound     : %f\n\n", option.Kbound);    
        end
        option.fp0 = option.fp1;
    end
    dt = toc(t1);

    %% Extract new labels
    XX = get_center(D, d);
    new_label = find_cluster(XX, option.clusterTol);
    output.timecost = dt;
    output.iternum = iter;

    function  JXJ = JXJ(X)
    %% Compute J*X*J where J = I-ee'/nn;
        nX   = size(X,1);
        Xe   = sum(X, 2);  
        eXe  = sum(Xe);    
        JXJ  = repmat(Xe,1,nX);
        JXJt = repmat(Xe',nX,1);
        JXJ  = -(JXJ + JXJt)/nX;
        JXJ  = JXJ + X + eXe/nX^2;
    end

    function [Z0,L1,L2]= EVD(A,option)
        %% calculate the first r largest eigenvalue and eigenvectors 
        A = (A + A')/2;
        [V0,P0] = eigs(A,option.r);
        P00 = diag(P0);
        P0 = max(P00,0);
        r1 = length(find(P0>0));
        tmp = V0(:,1:option.r);
        for i=1:r1
            tmp(:,i)=V0(:,i)*P0(i);
        end
        Z0 = tmp*V0(:,1:option.r)';
        L1 = P00;
        L2 = P0;
    end

    function [pik,L1,L2] = pi_k(A,option)
        %% \pi_k(A) = PCA(JAJ) + A - JAJ
        tmp1 = JXJ(A);
        [tmp2,L1,L2] = EVD(tmp1,option);
        pik = tmp2 + A - tmp1;
    end

    function fp = fp(D,pik_z,option)
        fp = sum(sum(option.W.*D + option.gamma * option.omega .* sqrt(D))) +...
            option.rho * (0.5 * norm(D, 'fro')^2 - 0.5 * norm(pik_z, 'fro')^2);
    end

    function X = get_center(D, feature)
        %% calculate data center from EDM solution
        nn = size(D,1);
        fullJDJ = -0.5 * JXJ(D);
        fullJDJ = 0.5 * (fullJDJ + fullJDJ');
        % eigenvalue decomposition of -1/2 (JDJ)
        [V0,P0] = eigs(fullJDJ, feature);
        P0 = sqrt(max(P0,0));
        XX = P0*V0';
        X = XX(:,nn/2+1:end);
    end

    function [cluster_id, num_cluster] = find_cluster(X,tol)
        %% assign labels for data points
        if isempty(X)
            error('Input Data must be nonempty.\n');
        end
        [m,nn] = size(X);
        index_temp = 1:nn;
        size_index = nn;
        cluster_id = ones(nn,1);
        reference_id = 0;
        while size_index > 0
            reference_id = reference_id + 1;
            reference_point = X(:,index_temp(1));
            cluster_id(index_temp(1)) = reference_id;
            index_temp = index_temp(2:end);
            if (true) 
                Xdiff = X(:,index_temp)-reference_point*ones(1,length(index_temp));
                normXdiff = sqrt(sum(Xdiff.*Xdiff));
                % find nearest index
                idx = find(normXdiff < tol*m);
                index_t = index_temp(idx); 
                cluster_id(index_t) = reference_id;
            end
            % remove processed points
            index_temp = setdiff(index_temp,index_t);
            size_index = length(index_temp);
        end
        num_cluster = reference_id;
    end
end