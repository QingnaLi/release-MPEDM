%%*************************************************************************
%% DEMO: 
%% This is a demonstration file for the algorithm in the following paper:
%% A Euclidean Distance Matrix Model for Convex Clustering. Zhaowei Wang, Xiaowen Liu, Qingna Li. Journal of Optimization Theory and Applications.
%% MP-EDM -- Majorization Penalty Euclidean Distance Matrix method
%% Copyright (c) 2023 by
%% Zhaowei Wang, Qingna Li and Xiaowen Liu
%% Last modified by Zhaowei Wang and Qingna Li on 2023.12.15
%% Please contact qnl@bit.edu.cn and wangzhaowei23@mails.ucas.ac.cn for more information
%%*************************************************************************

clc
clear

addpath(genpath("./"));

%% datasetNo:
%% =========================================
%% n is the number of data points
%% No.1 = 250noshuffle     Five clusters of random generated points, no shuffle (n = 250, d = 2)
%% No.2 = 250shuffle       Five clusters of random generated points, with shuffle (n = 250, d = 2)
%% No.3 = iris             (n = 150, d = 4)
%% No.4 = mnist            A subset of mnist dataset, select randomly (n = 10000, d = 784)
%% No.5 = wine             (n = 150, d = 13)
%% No.6 = user_modelling   (n = 403, d = 5)
%% No.7 = letter           A subset of Letter-Recognition (n = 20000, d = 16)
%% ==========================================
datasetNo = 3;

% get parameters and input matrix
[option, A, reallabel] = getInputX(datasetNo);
% main function, MP-EDM algorithm
[outputInfo, newlabel] = MPEDM(option, A);
% print clustering measurements and solution information
printOutput(outputInfo, newlabel, reallabel);


function option=getOptions()
    %% options for the demo
    %% =========================================
    %% r: rhs of rank constraint rank(JXJ) <= r
    %% batch: number of data points
    %% max_iter: max iteration count
    %% phi: defines the weight matrix W, W_ij = exp(-\phi * (x_i-x_j)^2) if a_i \in KNN(a_j) or a_j \in KNN(a_i)
    %% k : defines the neighbor of a_i : KNN(a_i) = {a_j | a_j is a_i's k-nearest neighbor}
    %% gamma : penalty parameter for original clustering problem
    %% rho : penalty parameter for subproblem
    %% Fbound : convergence tolerance, \epsilon_F
    %% Kbound : convergence tolerance, \epsilon_K
    %% clusterTol : convergence tolerance, \epsilon_d
    %% =========================================

    option.r = 4;
    option.batch = 150;
    option.max_iter = 100;
    option.phi = 0.5;
    option.k = 50;
    option.gamma = 2;
    option.rho = 100;
    option.Fbound = 5e-3;
    option.Kbound = 1e-3;    
    option.clusterTol = max(log2(option.batch),10) * option.Kbound;
end

function [option, A, reallabel] = getInputX(type)
    %% set parameters and get input data 
    option = getOptions();
    % select dataset
    switch type
        case 1 %"250noshuffle"
            data = load("data/250noshuffle.mat");
        case 2 %"250shuffle"
            data = load("data/250shuffle.mat");
        case 3 %"iris"
            data = load("data/iris.mat");
        case 4 %"mnist"
            data = load("data/mnist.mat");
        case 5 %"wine"
            data = load("data/wine.mat");
        case 6 %"user_modeling"
            data = load("data/user_modeling.mat");
        case 7 %'letter'
            data = load("data/letter-recognition.mat");
        otherwise
            error("Unknown dataset!");
    end 
    A = data.A';
    label = data.label;
    dataMaxbatch = size(A,2);
    A = A(:, 1:min(option.batch, dataMaxbatch));
    reallabel = label(1:min(option.batch,dataMaxbatch));
end

function printOutput(outputInfo, newlabel, reallabel)
    %% evaluate clustering result
    real_label = reallabel';
    new_label = newlabel';
    outputInfo.clusterNum = max(newlabel);
    outputInfo.realClusterNum = max(reallabel);
    outputInfo.RI = RandIndex(real_label, new_label);
    outputInfo.nmi = NMI(real_label, new_label);
    [outputInfo.fmeasure, outputInfo.purity] = Fmeasure(real_label, new_label);
    %% print output information
    fprintf('  TimeCost:%fs\n', outputInfo.timecost)
    fprintf('  Iter Num:%g\n', outputInfo.iternum)
    fprintf('  NMI: %.3f\n', outputInfo.nmi)
    fprintf('  Rand index: %.3f\n', outputInfo.RI)
    fprintf("  Fmeasure: %.3f\n", outputInfo.fmeasure)
    fprintf("  purity/accuracy: %.3f\n", outputInfo.purity)
end

function RI=RandIndex(c1,c2)
   %% calculate Rand Indices to compare two partitions
   if nargin < 2 || min(size(c1)) > 1 || min(size(c2)) > 1
      error('RandIndex: Requires two vector arguments')
      return
   end

   % construct contingency matrix
   C=Contingency(c1,c2);
   n=sum(sum(C));
   % sum of squares of sums of rows
   nis=sum(sum(C,2).^2);
   % sum of squares of sums of columns
   njs=sum(sum(C,1).^2);

   % total number of pairs of entities
   t1=nchoosek(n,2);
   % sum over rows & columnns of nij^2
   t2=sum(sum(C.^2));
   t3=.5*(nis+njs);

   A=t1+t2-t3;
   RI=A/t1;

   function Cont=Contingency(Mem1,Mem2)
       if nargin < 2 || min(size(Mem1)) > 1 || min(size(Mem2)) > 1
          error('Contingency: Requires two vector arguments')
          return
       end
    
       Cont=zeros(max(Mem1),max(Mem2));
       for i = 1:length(Mem1)
          Cont(Mem1(i),Mem2(i))=Cont(Mem1(i),Mem2(i))+1;
       end
    end
end


function [FMeasure,Accuracy] = Fmeasure(P,C)
    %% calculate f-measure of clustering results
    N = length(C);
    p = unique(P);
    c = unique(C);
    P_size = length(p);
    C_size = length(c);
    Pid = double(ones(P_size,1)*P == p'*ones(1,N) );
    Cid = double(ones(C_size,1)*C == c'*ones(1,N) );
    CP = Cid*Pid';
    Pj = sum(CP,1);
    Ci = sum(CP,2);
    
    % precision, recall and F-score
    precision = CP./( Ci*ones(1,P_size) );
    recall = CP./( ones(C_size,1)*Pj );
    F = 2*precision.*recall./(precision+recall);
    
    % Fmeasure and Accuracy
    FMeasure = sum( (Pj./sum(Pj)).*max(F) );
    Accuracy = sum(max(CP,[],2))/N;
end

function MIhat = NMI(A, B)
    %% calculate NMI Normalized mutual information
    if length(A) ~= length(B)
        error('length( A ) must == length( B)');
    end
    N = length(A);
    A_id = unique(A);
    K_A = length(A_id);
    B_id = unique(B);
    K_B = length(B_id);
    % Mutual information
    A_occur = double (repmat( A, K_A, 1) == repmat( A_id', 1, N ));
    B_occur = double (repmat( B, K_B, 1) == repmat( B_id', 1, N ));
    AB_occur = A_occur * B_occur';
    P_A= sum(A_occur') / N;
    P_B = sum(B_occur') / N;
    P_AB = AB_occur / N;
    MImatrix = P_AB .* log(P_AB ./(P_A' * P_B)+eps);
    MI = sum(MImatrix(:));
    % Entropies
    H_A = -sum(P_A .* log(P_A + eps),2);
    H_B= -sum(P_B .* log(P_B + eps),2);
    % Normalized Mutual information
    MIhat = MI / sqrt(H_A*H_B);
end
